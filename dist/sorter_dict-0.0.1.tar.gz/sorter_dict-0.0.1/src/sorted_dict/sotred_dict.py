


class sorted_dict:
    def __init__(self):
        self.d= dict()
    
    def test(self):
        print("\n\n\tInside test")